import React from "react";

export const Products_2 = () => {
  return (
    <>
      <div>AllProduct_2</div>
    </>
  );
};
