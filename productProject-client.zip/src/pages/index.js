export * from "./home/home.pages.jsx";
export * from "./contactUs/contactUs.pages.jsx";
export * from "./products-2/allProduct-2.pages.jsx";
export * from "./products-1/allProduct-1.pages.jsx";
export * from "./aboute/aboute.pages.jsx";
