import React from "react";

export const Aboute = () => {
  return (
    <>
      <div>Aboute</div>
    </>
  );
};
